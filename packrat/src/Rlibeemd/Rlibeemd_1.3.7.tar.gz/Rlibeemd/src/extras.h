
#ifndef _EXTRAS_H_
#define _EXTRAS_H_

void printError(libeemd_error_code err);

#endif
